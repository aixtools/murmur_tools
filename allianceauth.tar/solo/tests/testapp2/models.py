from solo.models import SingletonModel


class SiteConfiguration(SingletonModel):
    class Meta:
        verbose_name = "Site Configuration 2"
